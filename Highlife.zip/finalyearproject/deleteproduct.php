<?php
    include_once 'functions.php';
    
    $paraResultId = checkParamId('id');

    if (is_numeric($paraResultId)) {
        # code...
        $productID = validate($paraResultId);

        $product = getById('products',$productID);

        if ($product['status'] == 200) 
        {
            # code...
            $response = delete('products' , $productID);
            if ($response) {
                # code...
                $deleteImage = "../".$product['data']['img'];
                if (file_exists($deleteImage)) {
                    # code...
                    unlink($deleteImage);
                }
                redirect('products.php','Product Deleted Successfully');
            }
            else {
                # code...
                redirect('products.php','Something Went Wrong');
            } 
        }
        else {
            # code...
            redirect('products.php',$product['message']);
        }
    }
    else {
        redirect('products.php','Something Went Wrong');
    }
?>