<?php
error_reporting(0);
require 'partials/dbconnect.php';
function validate($inputData)
{

    global $con;
    $validatedData = mysqli_real_escape_string($con, $inputData);
    return trim($validatedData);
}

function redirect($url, $status)
{

    $_SESSION['status'] = $status;
    echo "<script>window.location.replace('$url');</script>";
    // header('Location:'.$url);
    exit(0);
}

function alertMessage()
{

    if (isset($_SESSION['status'])) {
        # code...
        echo ' <div class="alert alert-warning alert-dismissible fade show" role="alert">
            ' . $_SESSION['status'] . '
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
        unset($_SESSION['status']);
    }
}

function insert($tableName, $data)
{
    global $con;
    $table = validate($tableName);

    $colums = array_keys($data);
    $values = array_values($data);

    $finalColoum = implode(',', $colums);
    $finalValues = "'" . implode("' ,'", $values) . "'";

    $query = "INSERT INTO $table ($finalColoum) VALUE ($finalValues)";
    $result = mysqli_query($con, $query);
    return $result;
}

function update($tableName, $id, $data)
{
    global $con;
    $table = validate($tableName);
    $id = validate($id);

    $updateDataString = "";

    foreach ($data as $column => $value) {
        $updateDataString .= $column . "='" . mysqli_real_escape_string($con, $value) . "',";
    }

    $finalUpdateData = rtrim($updateDataString, ',');

    $query = "UPDATE $table SET $finalUpdateData WHERE id = '$id'";
    $result = mysqli_query($con, $query);

    return $result;
}

function getAll($tableName, $status = NULL)
{
    global $con;
    $table = validate($tableName);
    $status = validate($status);
    if ($status == 'status') {
        # code...
        $query = "SELECT * FROM $table WHERE status ='0'";
    } else {
        $query = "SELECT * FROM $table";
    }
    return mysqli_query($con, $query);
}
function getById($tableName, $id)
{
    global $con;
    $table = validate($tableName);
    $id = validate($id);

    $query = "SELECT * FROM $table WHERE id= '$id' LIMIT 1";
    $result = mysqli_query($con, $query);

    if ($result) {
        # code.

        if (mysqli_num_rows($result) == 1) {
            # code...
            $row = mysqli_fetch_assoc($result);
            $response = [
                'status' => 200,
                'data' => $row,
                'message' => ' Record Found',

            ];
            return $response;
        } else {

            $response = [
                'status' => 404,
                'message' => 'No Data Found',

            ];
            return $response;
        }
    } else {
        # code...
        $response = [
            'status' => 500,
            'message' => 'Something went Wrong',

        ];
        return $response;
    }
}

function delete($tableName, $id)
{
    global $con;
    $table = validate($tableName);
    $id = validate($id);

    $query = "DELETE FROM $table WHERE id= '$id' LIMIT 1";
    $result = mysqli_query($con, $query);
    return $result;
}
function checkParamId($type)
{
    if (isset($_GET[$type])) {
        # code...
        if ($_GET[$type] != '') {
            # code...
            return $_GET[$type];
        } else {
            # code...
            return '<h5>No id Found</h5>';
        }
    } else {
        # code...
        return '<h5>No id Given</h5>';
    }
}

function jsonResponse($status, $status_type, $message)
{

    $response = [
        'status' => $status,
        'status_type' => $status_type,
        'message' => $message,
    ];
    echo json_encode($response);
    return;
}
function signup($data)
{
    $errors = array();

    //validate 
    if (!preg_match('/^[a-zA-Z]+$/', $data['username'])) {
        $errors[] = "Please enter a valid username";
    }

    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email";
    }

    if (strlen(trim($data['password'])) < 4) {
        $errors[] = "Password must be atleast 4 chars long";
    }

    if ($data['password'] != $data['password2']) {
        $errors[] = "Passwords must match";
    }

    $check = database_run("select * from users where email = :email limit 1", ['email' => $data['email']]);
    if (is_array($check)) {
        $errors[] = "That email already exists";
    }

    //save
    if (count($errors) == 0) {

        $arr['username'] = $data['username'];
        $arr['email'] = $data['email'];
        $arr['password'] = hash('sha256', $data['password']);
        $arr['date'] = date("Y-m-d H:i:s");

        $query = "insert into users (username,email,password,date) values 
            (:username,:email,:password,:date)";

        database_run($query, $arr);
    }
    return $errors;
}

function login($data)
{
    $errors = array();

    //validate 
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email";
    }

    if (strlen(trim($data['password'])) < 4) {
        $errors[] = "Password must be atleast 4 chars long";
    }

    //check
    if (count($errors) == 0) {

        $arr['email'] = $data['email'];
        $password = hash('sha256', $data['password']);

        $query = "select * from users where email = :email limit 1";

        $row = database_run($query, $arr);

        if (is_array($row)) {
            $row = $row[0];

            if ($password === $row->password) {

                $_SESSION['USER'] = $row;
                $_SESSION['LOGGED_IN'] = true;
            } else {
                $errors[] = "wrong email or password";
            }
        } else {
            $errors[] = "wrong email or password";
        }
    }
    return $errors;
}

function database_run($query, $vars = array())
{
    $string = "mysql:host=localhost;dbname=fyp";
    $con = new PDO($string, 'root', '');

    if (!$con) {
        return false;
    }

    $stm = $con->prepare($query);
    $check = $stm->execute($vars);

    if ($check) {

        $data = $stm->fetchAll(PDO::FETCH_OBJ);

        if (count($data) > 0) {
            return $data;
        }
    }

    return false;
}

function check_login($redirect = true)
{

    if (isset($_SESSION['USER']) && isset($_SESSION['LOGGED_IN'])) {

        return true;
    }

    if ($redirect) {
        header("Location: login.php");
        die;
    } else {
        return false;
    }
}

function check_verified()
{

    $id = $_SESSION['USER']->id;
    $query = "select * from users where id = '$id' limit 1";
    $row = database_run($query);

    if (is_array($row)) {
        $row = $row[0];

        if ($row->email == $row->email_verified) {

            return true;
        }
    }

    return false;
}
 function getCount($tableName){
    global $con;

    $table = validate($tableName);
    $query ="SELECT * FROM $table";
    $query_run = mysqli_query($con, $query);
    
    if ($query_run ) {
        # code...
        $total_count = mysqli_num_rows($query_run);
        return $total_count;
    } else {
        # code...
        return 'Something Went Wrong!';
    }
    

 }