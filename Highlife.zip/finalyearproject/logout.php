<?php
session_start();
unset($_SESSION['authenticated']);
unset($_SESSION['auth_user']);
var_dump($_SESSION);
$_SESSION['status'] = "You are Logged Out Successfully";
header("location: login.php")
?>
