<?php
include 'partials/dbconnect.php';
include_once 'functions.php';

$paramResult = checkParamId('index');
if (is_numeric($paramResult)) {
    # code...

    $indexValue = validate($paramResult);
    if (isset($_SESSION['productItem']) && isset($_SESSION['productItemIds'])) {
        # code...
        unset($_SESSION['productItem'][$indexValue]);
        unset($_SESSION['productItemIds'][$indexValue]);

        redirect('bill.php', 'Item Removed  ');
    } else {
        # code...
        redirect('bill.php', 'There is no Item');
    }
} else {
    redirect('bill.php', 'param not numeric');
}
?>