<?php
session_start();
include 'partials/dbconnect.php';
if (isset($_POST['login_btn'])) {
    # code...

    if (!empty(trim($email = $_POST["email"])) && !empty(trim($email = $_POST["password"]))) {
        # code...
        $email = mysqli_real_escape_string($con, $_POST["email"]);
        $password = mysqli_real_escape_string($con, $_POST["password"]);
        $type = $_POST["type"];

        $login_query = "SELECT * FROM users WHERE email='$email' AND password='$password' LIMIT 1";
        $login_query_run = mysqli_query($con, $login_query);

        if (mysqli_num_rows($login_query_run) > 0) {
            # code...
            $row = mysqli_fetch_array($login_query_run);
            // echo $row['verify_status'];

            if ($row['verify_status'] == "1") {
                # code...
                $_SESSION['authenticated'] = TRUE;
                $_SESSION['auth_user'] = [
                    'username' => $row['name'],
                    'email' => $row['email'],
                    'id' => $row['id'],
                    'type' => $row['type'],
                ];
                $_SESSION['status'] = "You Are Logged in Successfully";
                // Redirect based on user type
                if ($row['type'] == "Admin") {
                    header("location: index.php");
                } else {
                    header("location: user.php");
                }
                exit(0);
            } else {
                # code...
                $_SESSION['status'] = "Please Varify Your Email to Login";
                header("location: login.php");
                exit(0);
            }
        } else {
            # code...
            $_SESSION['status'] = "Invalid Email or Password";
            header("location: login.php");
            exit(0);
        }
    } else {
        # code...
        $_SESSION['status'] = "All Fields are Mendatory";
        header("location: login.php");
        exit(0);
    }
}
