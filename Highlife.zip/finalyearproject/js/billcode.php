<?php
    // include 'partials/dbconnect.php';
    include_once 'functions.php';

    if (!isset($_SESSION['productItem'])) {
        # code...
        $_SESSION['productItem'] = [];
    }
    if (!isset($_SESSION['productItemIds'])) {
        # code...
        $_SESSION['productItemIds'] = [];
    }


    if (isset($_POST['addproduct'])) {
        # code...
        $productId = validate($_POST['product_id']);
        $quantity = validate($_POST['quantity']);

        $checkProducts = mysqli_query($con, "SELECT * FROM products WHERE id='$productId' LIMIT 1 ");
        if ($checkProducts) {
            # code...
            if (mysqli_num_rows($checkProducts) > 0) {
                # code...

                $row = mysqli_fetch_assoc($checkProducts);
                if ($row['quantity'] < $quantity) {
                    # code...
                    redirect('bill.php', 'Only' . $row['quantity'] . 'Quantity Available');
                }

                $productData = [
                    'product_id' => $row['id'],
                    'name' => $row['name'],
                    'img' => $row['img'],
                    'price' => $row['price'],
                    'description' => $row['description'],
                    'quantity' => $quantity,

                ];
                if (!in_array($row['id'], $_SESSION['productItemIds'])) {
                    # code...
                    array_push($_SESSION['productItemIds'], $row['id']);
                    array_push($_SESSION['productItem'], $productData);
                } else {
                    # code...
                    foreach ($_SESSION['productItem'] as $key => $productSessionItem) {
                        # code...
                        if ($productSessionItem['product_id'] == $row['id']) {
                            # code...

                            $newQuantity = $productSessionItem['quantity'] + $quantity;


                            $productData = [
                                'product_id' => $row['id'],
                                'name' => $row['name'],
                                'img' => $row['img'],
                                'price' => $row['price'],
                                'description' => $row['description'],
                                'quantity' => $newQuantity,

                            ];
                            $_SESSION['productItem'][$key] = $productData;
                        }
                    }
                }
                redirect('bill.php', 'Item Added' . $row['name']);
            } else {
                # code...
                redirect('bill.php', 'No Product Found');
            }
        } else {
            redirect('bill.php', 'Something Went Wrong');
        }
    }

    if (isset($_POST['productIncDec'])) {
        # code...
        $productId = validate($_POST['product_id']);
        $quantity = validate($_POST['quantity']);

        $flag =  false;

        foreach ($$_SESSION['productItem'] as $key => $item) {
            # code...
            if ($item['product_id'] == $productId) {
                # code...
                $flag =  true;
                $_SESSION['productItem'][$key]['quantity'] = $quantity;
            }
        }
        if ($flag) {
            # code...
            jsonResponse(200, "success", "Quantity Updated");
        } else {
            # code...
            jsonResponse(500, "error", "Something Went Wrong. Please Re-fresh ");
        }
    }
?>  