<?php
    include 'partials/dbconnect.php';

    if (isset($_GET['deleteid'])) {

        $id = $_GET['deleteid'];
        $sql = "DELETE FROM `armature` WHERE `id` = $id";

        $result = mysqli_query($con,$sql);

        if ($result) {
            # code...   
            echo '';
          ;
            ?>
            <meta http-equiv="refresh" content="0;url=http://localhost/finalyearproject/armature.php"/>
            <?php
        }
        else{
            die(mysqli_error($con));
        }



    };
?>
