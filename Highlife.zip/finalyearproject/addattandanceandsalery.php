<?php
error_reporting(0);
include ('authentication.php');

include 'partials/dbconnect.php';
include_once 'functions.php';

if (isset($_POST['submit'])) {

    // Form Data upload 
    $user = $_SESSION['auth_user']['email'];
    $query = mysqli_query($con, "SELECT * FROM `users` WHERE email = '$user'");
    $row = mysqli_fetch_array($query);
    $id1 = $row['id'];

    $date = $_POST["date"];
    $attandance = isset($_POST["attandance"]) ? 1 : 0; // Assuming 1 for present, 0 for absent
    $work = $_POST["work"];
    $over_time = $_POST["over_time"];
    $money_received = $_POST["money_received"];
    $totalsalery = $_POST["totalsalery"];
    $checkid = $_POST["checkid"];
    $timestamp = date("Y-m-d H:i:s"); // Current timestamp

    // Insert the new record
    $sql = "INSERT INTO `attandanceandsalery` (`date`, `attandance`, `work`, `over_time`, `money_received`, `totalsalery`, `timestamp`, `employe_id`) VALUES ('$date', '$attandance', '$work', '$over_time', '$money_received', '$totalsalery', '$timestamp', '$checkid')";

    $result = mysqli_query($con, $sql);
    if ($result) {
        // Record inserted successfully
        header('location:attandanceandsalery.php');
    } else {
        // Error inserting record
        echo "The record has not been inserted successfully because of this error: " . mysqli_error($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="76x76" href="./img/Heigh Life.png">
    <link rel="icon" type="image/png" href="./img/Heigh Life.png">
    <title>Heigh Life Fans</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include '/xampp/htdocs/finalyearproject/partials/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <?php include '/xampp/htdocs/finalyearproject/partials/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><b>Add Employee Record</b></h1>
                    </div>

                    <!-- Content Row -->
                    <div class="card">
                        <div class="card-body">
                            <form class="mb-5" method="post" enctype="multipart/form-data">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <a class="btn btn-primary text-white" onclick="location.href='employe.php'" type="submit">
                                                < Back</a>
                                        </div>
                                        <div class="col-md-6">
                                            <button style="float: right" type="submit" class="btn btn-success" name="submit" value="submit">Add ></button>
                                        </div>
                                    </div>
                                </div>

                                <div class="container">
                                    <div class="form-row mt-3">
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputdate">Date:</label>
                                            <input type="date" class="form-control" id="date" name="date">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputattandance">Attandance:</label>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" id="attandance" name="attandance">
                                                <label class="form-check-label" for="attandance">
                                                    Present
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputwork">Work:</label>
                                            <input type="text" class="form-control" id="work" name="work">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputovertime">Over_time:</label>
                                            <input type="text" class="form-control" id="over_time" name="over_time">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputmoney_received">Money_received:</label>
                                            <input type="text" class="form-control" id="money_received" name="money_received">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputsalery">Total</label>
                                            <input type="text" class="form-control" id="totalsalery" name="totalsalery">
                                        </div>
                                    </div>
                                    <div class="col-md-3 mt-2">
                                        <label for="checkid">Employees</label>
                                        <select name="checkid" class="form-select">
                                            <option value="">--Select Employees--</option>
                                            <?php
                                            $products = getAll('employes');
                                            if ($products) {
                                                if (mysqli_num_rows($products) > 0) {
                                                    foreach ($products as $productItem) {
                                                        echo "<option value='{$productItem['id']}'>{$productItem['name']}</option>";
                                                    }
                                                } else {
                                                    echo '<option value="">No Employee Found</option>';
                                                }
                                            } else {
                                                echo '<option value="">Something Went Wrong</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End of Main Content -->

                    <!-- Footer -->
                    <?php include '/xampp/htdocs/finalyearproject/partials/footer.php'; ?>
                    <!-- End of Footer -->
                </div>
                <!-- End of Content Wrapper -->
            </div>
            <!-- End of Page Wrapper -->

            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>

            <!-- Logout Modal-->
            <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            <a class="btn btn-primary" href="login.php">Logout</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bootstrap core JavaScript-->
            <script src="vendor/jquery/jquery.min.js"></script>
            <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

            <!-- Core plugin JavaScript-->
            <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

            <!-- Custom scripts for all pages-->
            <script src="js/sb-admin-2.min.js"></script>

            <!-- Page level plugins -->
            <script src="vendor/chart.js/Chart.min.js"></script>

            <!-- Page level custom scripts -->
            <script src="js/demo/chart-area-demo.js"></script>
            <script src="js/demo/chart-pie-demo.js"></script>
</body>

</html>
