<?php
    session_start();
    if (!$_SESSION['authenticated']) {
        # code...
     
        header('location:login.php');
    }
?>