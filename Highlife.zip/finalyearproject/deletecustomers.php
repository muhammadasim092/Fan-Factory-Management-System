<?php
     include 'partials/dbconnect.php';
     include_once 'functions.php';

     $paraResultId = checkParamId('id');
     if (is_numeric($paraResultId)) {
        # code...
        $customerId = validate($paraResultId);
        $customer = getById('customers', $customerId);

        if ($customer) {
            # code...
            $response = delete('customers', $customerId);

            if ($response) {
                # code...
                redirect('customers.php','Customer Deleted Successfully');
            }
            else {
                redirect('customers.php','Something Went Wrong');
            }
        }
     }
?>