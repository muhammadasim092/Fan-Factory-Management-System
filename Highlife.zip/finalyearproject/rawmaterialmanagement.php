<?php
error_reporting(0);
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="76x76" href="./img/Heigh Life.png">
    <link rel="icon" type="image/png" href="./img/Heigh Life.png">

    <title>Heigh Life Fans</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->

        <?php
        include '/xampp/htdocs/finalyearproject/partials/sidebar.php';
        ?>
        <!--  End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include '/xampp/htdocs/finalyearproject/partials/navbar.php';
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><b>RawMaterial Management</b></h1>
                        <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
                    </div>
                    <div class="container">
                        <div class="container">
                            <h2>Catagories</h2>
                        </div>
                        <div class="card">
                            <div class="row mt-3 justify-content-center">
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://img1.exportersindia.com/product_images/bc-full/2021/7/158321/watermark/1624441614_p_5475138_1123898.jpeg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Body plate</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consequatur aspernatur dolores molestias omnis inventore est cupiditate corrupti tempora distinctio rem?</p>
                                            <a href="bodyplate.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://5.imimg.com/data5/SELLER/Default/2022/11/IO/LB/MN/162012997/ceiling-fan-stator-250x250.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Rotor</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="rotor.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://thumbs.dreamstime.com/b/electric-dc-motor-rotors-copper-commutator-coil-wire-winding-isolated-white-background-two-engine-parts-steel-236952058.jpg
                                        " class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Armature
                                                
                                            </b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="armature.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Axel</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="axel.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://image.made-in-china.com/202f0j00eWGcYEnBvQbt/CCA-CCAM-Cu-Tc-CCC-CCS-Wire-Cable-Raw-Material-Copper-Clad-Aluminum-Wire-for-Cable.webp" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Copper Wire</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="copperwire.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://cpimg.tistatic.com/6973035/s/4/fd-fan-bearing.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Baring</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="baring.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Naka</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="naka.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://m.media-amazon.com/images/I/11URlkxX8WL._AC_UF894,1000_QL80_.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Blade</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="blade.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://5.imimg.com/data5/SELLER/Default/2022/2/CB/QO/XH/5092323/polished-steel-shank-500x500.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Shank</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="shank.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://5.imimg.com/data5/SELLER/Default/2021/10/WR/OW/IA/23699356/heavy-fan-extension-rod.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Rod</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="rod.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Paint</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="paint.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://i.ebayimg.com/images/g/V9oAAOSwJwZiPoA2/s-l400.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Capacitor</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="capacitor.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://image.made-in-china.com/202f0j00wbmhLPCnGWgy/Fan-Electric-Motor-Winding-Insulation-Paper-DMD.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Insulation</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="insulation.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQngi9N3J68zgeC9pDmtPEu8HlFAhmPMEeRyExtX1Sclw&s" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Screw</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="screw.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Seliving</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="seliving.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://5.imimg.com/data5/SELLER/Default/2021/8/EP/RD/JI/73910360/78mm-pp-ceiling-fan-canopy-500x500.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Canopi</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="canopi.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Sticker</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="sticker.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://5.imimg.com/data5/SELLER/Default/2021/12/XU/AN/XE/74999821/super-sonata-fan-thermocol-packaging-500x500.jpg" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Thermopole</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="thermopole.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="" class="card-img-top mh-70" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Body and Blade Shopper</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="bodybladeshopper.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                <ul>
                                    <div class="card" style="width: 18rem;">
                                        <img src="https://i.pinimg.com/474x/af/5d/6f/af5d6fb5d5f840cbd90e7cda7b855a52.jpg" class="card-img-top mh-70" alt="...">
                                        
                                        <div class="card-body">
                                            <h5 class="card-title"><b>Packing Box</b></h5>
                                            <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime itaque tempora atque impedit quasi magnam est nam ratione, reiciendis expedita?</p>
                                            <a href="packingbox.php" class="btn btn-primary">View Products</a>
                                        </div>
                                    </div>
                                </ul>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            include '/xampp/htdocs/finalyearproject/partials/footer.php';
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>