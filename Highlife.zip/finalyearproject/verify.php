<?php
session_start();
include 'partials/dbconnect.php';

if (isset($_GET['token'])) {

    $token = $_GET['token'];
    $verify_query = "SELECT token,verify_status FROM users WHERE token = '$token' LIMIT 1";
    $verify_query_run = mysqli_query($con, $verify_query);

    if (mysqli_num_rows($verify_query_run) > 0) {
        # code...
        $row = mysqli_fetch_array($verify_query_run);

        if ($row['verify_status'] == "0") {
            # code...
            $clicked_token = $row['token'];
            $updated_query = "UPDATE users SET verify_status='1' WHERE token='$clicked_token' LIMIT 1";
            $updated_query_run = mysqli_query($con, $updated_query);

            if ($updated_query_run) {
                # code...
                $_SESSION['status'] = " Your Account has been Varified Successfully! Please login";
                header("location: login.php");
                exit(0);

            } else {
                # code...
                $_SESSION['status'] = "Varification Failed";
                header("location: login.php");
                exit(0);
            }
        } else {
            # code...
            $_SESSION['status'] = "Email Already Varified. Please Login";
            header("location: login.php");
            exit(0);
        }
    } else {
        # code...
        $_SESSION['status'] = "This Token Doesnot Exists";
        header("location: login.php");
    }
} else {
    $_SESSION['status'] = "Not Allowed";
    header("location: login.php");
}
