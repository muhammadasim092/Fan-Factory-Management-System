<?php
error_reporting(0);
session_start();
include ('authentication.php');
include 'partials/dbconnect.php';
include_once 'functions.php';

if (isset($_POST['updateproducts'])) {
    $product_id = validate($_POST['product_id']);
    $productData = getById('products', $product_id);

    if (!$productData) {
        redirect('products.php', 'No such product found');
    }

    $name = validate($_POST['name']);
    $description = validate($_POST['description']);
    $quantity = validate($_POST['quantity']);
    $price = validate($_POST['price']);
    $status = isset($_POST['status']) ? 1 : 0;

    if ($_FILES['img']['size'] > 0) {
        $path = "../finalyearproject/img/products";
        $img_ext = pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION);
        $filename = time() . '.' . $img_ext;
        move_uploaded_file($_FILES['img']['tmp_name'], $path . "/" . $filename);
        $finalImg = "finalyearproject/img/products/" . $filename;

        $deleteimg = "../" . $productData['data']['img'];
        if (file_exists($deleteimg)) {
            unlink($deleteimg);
        }
    } else {
        $finalImg = $productData['data']['img'];
    }

    $data = [
        'name' => $name,
        'description' => $description,
        'quantity' => $quantity,
        'price' => $price,
        'img' => $finalImg,
        'status' => $status
    ];

    $result = update('products', $product_id, $data);

    if ($result) {
        redirect('editproducts.php?id=' . $product_id, 'Product Updated Successfully');
    } else {
        redirect('editproducts.php?id=' . $product_id, 'Something went wrong');
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="76x76" href="./img/Heigh Life.png">
    <link rel="icon" type="image/png" href="./img/Heigh Life.png">
    <title>Heigh Life Fans</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include '/xampp/htdocs/finalyearproject/partials/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include '/xampp/htdocs/finalyearproject/partials/navbar.php'; ?>
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><b>Edit Products</b></h1>
                    </div>
                    <div class="container">
                        <div class="card mt-4 shadow-sm">
                            <div class="card-header">
                                <h4 class="mb-0">Edit Products
                                    <a href="products.php" class="btn btn-danger float-right">Back</a>
                                </h4>
                            </div>
                            <div class="card-body">
                                <?php alertMessage(); ?>
                                <form action="editproducts.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                    $parValue = checkParamId('id');
                                    if (!is_numeric($parValue)) {
                                        echo '<h5>Id is not an integer</h5>';
                                        return false;
                                    }
                                    $product = getById('products', $parValue);
                                    if ($product) {
                                        if ($product['status'] == 200) {
                                    ?>
                                            <input type="hidden" name="product_id" value="<?= $product['data']['id']; ?>">
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for=""> Product Name</label>
                                                    <input type="text" name="name" required class="form-control" value="<?= $product['data']['name']; ?>">
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="">Description</label>
                                                    <input type="text" name="description" required class="form-control" value="<?= $product['data']['description']; ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="">Price</label>
                                                    <input type="text" name="price" required class="form-control" value="<?= $product['data']['price']; ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="">Quantity</label>
                                                    <input type="text" name="quantity" required class="form-control" value="<?= $product['data']['quantity']; ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="">Image</label>
                                                    <input type="file" name="img" class="form-control">
                                                    <img src="../<?= $product['data']['img']; ?>" style="width: 200px;height: 200px;" alt="Img">
                                                </div>
                                                <div class="col-md-6 mt-5 text-end">
                                                    <button class="btn btn-success float-right" name="updateproducts" type="submit">Update</button>
                                                </div>
                                            </div>
                                    <?php
                                        } else {
                                            echo '<h5>' . $product['message'] . '</h5>';
                                        }
                                    } else {
                                        echo '<h5>Something Went Wrong</h5>';
                                        return false;
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include '/xampp/htdocs/finalyearproject/partials/footer.php'; ?>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
</body>
</html>
