<?php
require_once 'vendor/autoload.php';

use Dompdf\Dompdf;

include 'partials/dbconnect.php';
$sql = "SELECT employes.*, attandanceandsalery.*
FROM employes
JOIN attandanceandsalery ON employes.id = attandanceandsalery.employe_id
WHERE employes.id = employe_id";
$stmt = $con->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
$rows = $result->fetch_all(MYSQLI_ASSOC);

$gt = 0;
$i = 1;

$html = '<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Report</title>
    <style>
        h2 {
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-align: center;
        }

        table {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {

            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        .mytable {
            text-align: right;
        }

        #sign {
            padding-top: 70px;
            text-align: center;
        }
    </style>
</head>

<body>
    <h2>User Report</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Attandance</th>
                <th>Work</th>
                <th>Over Time</th>
                <th>Money Received</th>
                <th>Total </th>
            </tr>
        </thead>
        <tbody>';

        foreach ($rows as $row) {
            # code...
            $html .='<tr>
            
            <td>'.$row['date'].'</td>
            <td>'.$row['attandance'].'</td>
            <td>'.$row['work'].'</td>
            <td>'.$row['over_time'].'</td>
            <td>'.$row['money_received'].'</td>

        </tr>';
       
        }
        $html .='     </tbody>
        <tr>
            <th colspan="4" class="mytable"> Total</th>
            <th>'.$row['totalsalery'].'</th>

        </tr>
        <tr>
            <td colspan="2" id="sign">Signature</td>
        </tr>
    </table>
</body>

</html>';

$dompdf = new Dompdf;
$dompdf->load_html($html);
$dompdf->setPaper('A4' , 'portrait');
$dompdf->render();
$dompdf->stream('report.pdf');
?>

            
   