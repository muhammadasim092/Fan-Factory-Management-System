<?php
    session_start();
    if (!isset($_SESSION['authenticated'])) {
        # code...
        $_SESSION['status'] = "Please Login to Access Your Profile";
        header("location: login.php");
        exit(0);
    }
?>