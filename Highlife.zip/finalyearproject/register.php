
<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="76x76" href="./img/Heigh Life.png">
    <link rel="icon" type="image/png" href="./img/Heigh Life.png">

    <title>Heigh Life Fans</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body style="background-image: url('https://images.unsplash.com/photo-1646840299746-0be3a2604eb0?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D');">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row ">
                <div class="col-lg-5 d-none d-lg-block bg-login " ><img src="img/Heigh Life.png" class="img-fluid img " style="margin-top: 75px;" alt="..."></div>
                    <!-- <div class="col-lg-5 d-none d-lg-block bg-register-image"></div> -->
                    <div class="col-lg-7">
                        <div class="alert">
                        <?php
                                if (isset($_SESSION['status'])) {
                                    # code...
                                ?>
                                <div class="alert alert-success">
                                <h4><?= $_SESSION['status']?></h4>
                                </div>
                                   <?php
                                    unset($_SESSION['status']);
                                } 
                            ?>
                        </div>
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>
                            <form class="form" action="code.php" method="post">
                                <div class="mb-3">
                                    <label for="email" class="form-label"> Name:</label>
                                    <input type="name" class="form-control" id="name" placeholder="Your Name" name="name">
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email address:</label>
                                    <input type="email" class="form-control" id="email" placeholder="name@example.com" name="email">
                                </div>
                                <label for="inputPassword" class="form-label">Password:</label>
                                <input type="password" id="password" name="password" class="form-control" aria-describedby="passwordHelpBlock">
                               
                                <label for="inputPassword" class="form-label">Confirm Password:</label>
                                <input type="password" id="cpassword" name="cpassword" class="form-control" aria-describedby="passwordHelpBlock">
                                <small>Make sure you enter the same Password</small>
                                <br />
                                <!-- <select class="form-select mt-1" aria-label="Default select example" name="type">
                                    <option selected>Select Type</option>
                                    <option value="User">User</option>
                                    <option value="Admin">Admin</option>
                                </select> -->

                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Admin" id="invalidCheck"  name="type" id="type">
                                    <label class="form-check-label" for="invalidCheck">
                                        is Admin?
                                    </label>  
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="User" id="invalidCheck"  name="type" id="type">
                                    <label class="form-check-label" for="invalidCheck">
                                        is User?
                                    </label>  
                                </div>


                                <div class="container">
                                    <button type="submit" style="margin-left: 105px;" class="btn btn-primary mt-3" name="register_btn">Resister</button>
                                </div>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password.php">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="login.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>