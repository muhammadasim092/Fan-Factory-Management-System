<?php

include('authentication.php');
include('partials/dbconnect.php');
include('functions.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="apple-touch-icon" sizes="76x76" href="./img/Heigh Life.png">
    <link rel="icon" type="image/png" href="./img/Heigh Life.png">

    <title>Heigh Life Fans</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">





</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->

        <?php
        include '/xampp/htdocs/finalyearproject/partials/sidebar.php';
        ?>
        <!--  End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include '/xampp/htdocs/finalyearproject/partials/navbar.php';
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->

                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><b>Order Print:</b></h1>
                        <a href="orders.php" class=" btn  btn-primary shadow-sm">Back</a>
                    </div>
                    <div class="card mt-4 shadow-sm">

                        <div class="card-body">
                            <div id="mybillingArea">


                                <?php
                                if (isset($_GET['track'])) {
                                    # code...
                                    $trackingNo = validate($_GET['track']);
                                    if ($trackingNo == '') {
                                        # code...
                                ?>
                                        <div class="text-center py-5">
                                            <h5>No Tracking No Found</h5>
                                            <div>
                                                <a href="orders.php" class="btn btn-primary mt-4">Go Back to Orders</a>
                                            </div>
                                        </div>
                                    <?php
                                    }

                                    $orderQuery = "SELECT o.*, c.* FROM orders o, customers c WHERE c.id= customer_id AND tracking_no ='$trackingNo' LIMIT 1";

                                    $orderQueryResult = mysqli_query($con, $orderQuery);
                                    if (!$orderQueryResult) {
                                        # code...
                                        echo '<h5>Something Went Wrong</h5>';
                                        return false;
                                    }
                                    if (mysqli_num_rows($orderQueryResult) > 0) {
                                        # code...
                                        $orderDataRow = mysqli_fetch_assoc($orderQueryResult);
                                        // print_r($orderDataRow);
                                    ?>
                                        <table style="width: 100%; margin-bottom: 20px;">
                                            <tbody>
                                                <tr>
                                                    <td style="text-align:center;" colspan="2">
                                                        <h4 style="font: size 20px; line-height: 30px; margin:2px; padding:0"><b>High Life Fans</b></h4>
                                                        <p>Eid Gah Road Near Railway Station</p>
                                                        <p>Munir Electrical Industries</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h4><b>Customer Details</b></h4>
                                                        <p>Customer Name: <?= $orderDataRow['name'] ?></p>
                                                        <p>Customer Phone: <?= $orderDataRow['phone'] ?></p>
                                                        <p>Customer Email: <?= $orderDataRow['email'] ?></p>
                                                    </td>
                                                    <td align="end">
                                                        <h4><b>Invoice Details</b></h4>
                                                        <h5>Account # 12345678 </h5>
                                                        <p>Invoice No: <?= $orderDataRow['invoice_no'] ?></p>
                                                        <p>Invoice Date: <?= date('d M Y') ?></p>
                                                        <p>Address: Eid Gah Road Near Railway Station </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <?php
                                    } else {
                                        # code...
                                        echo '<h5>No Data Found</h5>';
                                        return false;
                                    }
                                    $orderItemQuery = "SELECT oi.quantity as  orderItemQuantity, oi.price as orderItemPrice, o.*, oi.*,p.* FROM orders o, order_items oi, products p WHERE
                                oi.order_id=o.id AND p.id=oi.product_id AND o.tracking_no='$trackingNo'";

                                    $orderItemQueryResult = mysqli_query($con, $orderItemQuery);
                                    if ($orderItemQueryResult) {
                                        # code...
                                        if (mysqli_num_rows($orderItemQueryResult) > 0) {
                                            # code...
                                        ?>
                                            <div class="table-responsive mb-3">
                                                <table style="width:100%;" cellpadding="5">
                                                    <thead>
                                                        <tr>
                                                            <th align="start" style="border-bottom: 1px solid #ccc;" width="5%">ID</th>
                                                            <th align="start" style="border-bottom: 1px solid #ccc;" width="5%">Name</th>
                                                            <th align="start" style="border-bottom: 1px solid #ccc;" width="5%">Price</th>
                                                            <th align="start" style="border-bottom: 1px solid #ccc;" width="5%">Quantity</th>
                                                            <th align="start" style="border-bottom: 1px solid #ccc;" width="5%">Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $i = 1;

                                                        foreach ($orderItemQueryResult as $key => $row) :
                                                        ?>
                                                            <tr>
                                                                <td style="border-bottom: 1px solid #ccc;"><?= $i++; ?></td>
                                                                <td style="border-bottom: 1px solid #ccc;"><?= $row['name']; ?></td>
                                                                <td style="border-bottom: 1px solid #ccc;"><?= number_format($row['orderItemPrice'], 0); ?></td>
                                                                <td style="border-bottom: 1px solid #ccc;"><?= $row['orderItemQuantity']; ?></td>
                                                                <td style="border-bottom: 1px solid #ccc;" class="fw-bold">
                                                                    <?= number_format($row['orderItemPrice'] * $row['orderItemQuantity'], 0) ?>
                                                                </td>

                                                            </tr>
                                                        <?php endforeach; ?>
                                                        <tr>
                                                            <td colspan="4" align="end" style="font-weight:bold;">Grand Total</td>
                                                            <td colspan="1" style="font-weight:bold"><?= number_format($row['total_amount'], 0); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="5"> Payment Method: <?= $row['payment_mode']; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                    <?php
                                        } else {
                                            # code...
                                            echo '<h5>No Data Found</h5>';
                                            return false;
                                        }
                                    } else {
                                        # code...
                                        echo '<h5>Something Went Wrong</h5>';
                                        return false;
                                    }
                                } else {
                                    # code...
                                    ?>
                                    <div class="text-center py-5">
                                        <h5>No Tracking No Parameter Found</h5>
                                        <div>
                                            <a href="orders.php" class="btn btn-primary mt-4">Go Back to Orders</a>
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>
                            </div>

                            <div class="mt-4 text-end">
                                <button class="btn btn-primary" onclick="printMyBillingArea()">Print</button>
                                <button class="btn btn-danger" onclick="downloadPDF('<?= $orderDataRow['invoice_no'] ?>')">Download</button>
                            </div>


                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            include '/xampp/htdocs/finalyearproject/partials/footer.php';
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" integrity="sha512-qZvrmS2ekKPF2mSznTQsxqPgnpkI4DNTlrdUmTzrDgektczlKNRRhy5X5AAOnx5S09ydFYWWNSfcEqDTTHgtNA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" integrity="sha512-BNaRQnYJYiPSqHHDb58B0yaPfCu+Wgds8Gp/gU33kqBtgNS4tSPHuGibyoeqMV/TJlSKda6FXzoEyYGjTe+vXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    <script>
        function printMyBillingArea() {
            var divContents = document.getElementById("mybillingArea").innerHTML;
            var a = window.open('', '');
            a.document.write('<html><title>HighLife</title>');
            a.document.write('<body stylye="font-family: fangsong;">');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }

        window.jsPDF = window.jspdf.jsPDF;
        var docPDF = new jsPDF();

        function downloadPDF(invoiceNo) {
            // Ensure the element exists
            var elementHTML = document.querySelector("#mybillingArea");
            if (!elementHTML) {
                console.error("Element with ID 'mybillingArea' not found");
                return;
            }

            docPDF.html(elementHTML, {
                callback: function(docPDF) {
                    docPDF.save(invoiceNo + '.pdf');
                },
                x: 15,
                y: 15,
                width: 170,
                windowWidth: 650
            });
        }
    </script>

</body>