<?php
session_start();
include 'partials/dbconnect.php';
use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

function sendemail_varify($name,$email,$varify_token){
    
    $mail = new PHPMailer(true);

try {
    //Server settings
    $mail->isSMTP();                                            //Send using SMTP
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication

    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->Username   = '20014119-092@uog.edu.pk';                     //SMTP username
    $mail->Password   = 'gyxgkkgzsqlyijar';                               //SMTP password

    $mail->SMTPSecure = "tls";            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom("20014119-092@uog.edu.pk", $name);
    $mail->addAddress($email);     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = "Email Varification from HighLife";

    $email_template = "<h2>You have to Registered with Highlife</h2>
    <h5>Varify your Email Adress to login with below link</h5>
    <br/><br/>
    <a href='http://localhost/finalyearproject/verify.php?token=$varify_token'>Click me</a>";

    $mail->Body = $email_template;
    $mail->send();
    // echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}


if (isset($_POST['register_btn'])) {
    # code...
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user_type = $_POST['type'];
    $varify_token = md5(rand());

    $check_email_query = "SELECT email FROM users WHERE email = '$email' LIMIT 1";
    $check_email_query_run = mysqli_query($con, $check_email_query);

    if (mysqli_num_rows($check_email_query_run) > 0) {
        # code...

        $_SESSION['status'] = "Email Alerady Exists";
        header("location: register.php");
    } else {
        # code...
        $query = "INSERT INTO `users`(`name`, `email`, `password`,`token`, `type`) VALUES ('$name','$email','$password','$varify_token','$user_type')";

        $query_run = mysqli_query($con, $query);

        if ($query_run) {
            # code...
            sendemail_varify("$name","$email","$varify_token");
            $_SESSION['status'] = "Registration Successfull! Please Varify your Email";
            header("location: register.php");

        } else {
            # code...
            $_SESSION['status'] = "Registration Failedd";
            header("location: register.php");
        }
    }
}
