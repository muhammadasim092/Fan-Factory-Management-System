<?php
    include 'partials/dbconnect.php';

    if (isset($_GET['deleteid'])) {

        $id = $_GET['deleteid'];
        $sql = "DELETE FROM `supplier` WHERE `id` = $id";

        $result = mysqli_query($con,$sql);

        if ($result) {
            # code...   
            echo '';
          ;
            ?>
            <meta http-equiv="refresh" content="0;url=http://localhost/finalyearproject/supplier.php"/>
            <?php
        }
        else{
            die(mysqli_error($con));
        }



    };
?>
