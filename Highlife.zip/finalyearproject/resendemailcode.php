<?php
session_start();
include 'partials/dbconnect.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
//Load Composer's autoloader
require 'vendor/autoload.php';

function resend_email_varify($name, $email, $token)
{

    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                            //Send using SMTP
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication

        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->Username   = '20014119-092@uog.edu.pk';                     //SMTP username
        $mail->Password   = 'gyxgkkgzsqlyijar';                               //SMTP password

        $mail->SMTPSecure = "tls";            //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom("20014119-092@uog.edu.pk", $name);
        $mail->addAddress($email);     //Add a recipient

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = " Resend Email Varification from HighLife";

        $email_template = "<h2>You have to Registered with Highlife</h2>
        <h5>Varify your Email Adress to login with below link</h5>
        <br/><br/>
        <a href='http://localhost/finalyearproject/verify.php?token=$token'>Click me</a>";

        $mail->Body = $email_template;
        $mail->send();
        // echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}


if (isset($_POST['resentemailvarification'])) {
    # code...
    if (!empty(trim($_POST['email']))) {
        # code...
        $email = mysqli_real_escape_string($con, $_POST['email']);

        $check_email_query = "SELECT * FROM users WHERE email= '$email' LIMIT 1";
        $check_email_query_run = mysqli_query($con, $check_email_query);

        if (mysqli_num_rows($check_email_query_run) > 0) {
            # code...
            $row = mysqli_fetch_array($check_email_query_run);

            if ($row['verify_status'] == "0") {
                # code...
                $name = $row['name'];
                $email = $row['email'];
                $token = $row['token'];

                resend_email_varify($name, $email, $token);

                $_SESSION['status'] = "Varification Email Link has been Sent! Check you Inbox to verify ";
                header("location: login.php");
                exit(0);
            } else {
                # code...
                $_SESSION['status'] = "Email is Already Varified! Please login ";
                header("location: resendemailvarification.php");
                exit(0);
            }
        } else {
            # code...
            $_SESSION['status'] = "Email is not Registered Please Register Now";
            header("location: register.php");
            exit(0);
        }
    } else {
        # code...
        $_SESSION['status'] = "Please Enter the Email Field";
        header("location: resendemailvarification.php");
        exit(0);
    }
}
