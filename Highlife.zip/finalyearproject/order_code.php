<?php 
include 'partials/dbconnect.php';
include 'functions.php';

session_start(); // Ensure the session is started

// Initialize session variables if they do not exist
if (!isset($_SESSION['productItem'])) {
    $_SESSION['productItem'] = [];
}
if (!isset($_SESSION['productItemIds'])) {
    $_SESSION['productItemIds'] = [];
}



// Check if the form is submitted
if (isset($_POST['addproduct'])) {
    // Validate inputs
    $productId = validate($_POST['product_id']);
    $quantity = validate($_POST['quantity']);

    // Query to check if the product exists
    $checkProducts = mysqli_query($con, "SELECT * FROM products WHERE id='$productId' LIMIT 1");

    if ($checkProducts) {
        if (mysqli_num_rows($checkProducts) > 0) {
            $row = mysqli_fetch_assoc($checkProducts);

            // Check if the requested quantity is available
            if ($row['quantity'] < $quantity) {
                redirect('bill.php', 'Only ' . $row['quantity'] . ' quantity available');
            }

            // Prepare product data to add to the session
            $productData = [
                'product_id' => $row['id'],
                'name' => $row['name'],
                'img' => $row['img'],
                'price' => $row['price'],
                'description' => $row['description'],
                'quantity' => $quantity,
            ];

            // Check if the product is already in the session
            if (!in_array($row['id'], $_SESSION['productItemIds'])) {

                array_push($_SESSION['productItemIds'], $row['id']);
                array_push($_SESSION['productItem'], $productData);

            } else {
                // Update the quantity if the product is already in the session
                foreach ($_SESSION['productItem'] as $key => $productSessionItem) {
                    if ($productSessionItem['product_id'] == $row['id']) {
                        $newQuantity = $productSessionItem['quantity'] + $quantity;

                        $productData['quantity'] = $newQuantity;
                        $_SESSION['productItem'][$key] = $productData;
                    }
                }
            }
            redirect('bill.php', 'Item Added: ' . $row['name']);
        } else {
            redirect('bill.php', 'No Product Found');
        }
    } else {
        redirect('bill.php', 'Something Went Wrong');
    }
}



if (isset($_POST['productIncDec'])) {

    $productId = validate($_POST['product_id']);
    $quantity = validate($_POST['quantity']);

    $flag = false;
    foreach ($_SESSION['productItem'] as $key => $item) {
        if ($item['product_id'] == $productId) {
            $flag = true;
            $_SESSION['productItem'][$key]['quantity'] = $quantity;
        }
    }

    if ($flag) {
        jsonResponse(200, "success", "Quantity Updated");
    } else {
        jsonResponse(500, "error", "Something Went Wrong. Please Refresh");
    }
}


if (isset($_POST['proceedToPlaceBtn'])) {
    # code...
    $phone = validate($_POST['customerphone']);
    $payment_mode = validate($_POST['payment_mode']);

    // Checking for customer 

    $checkCustomer = mysqli_query($con, "SELECT * FROM customers WHERE phone = '$phone' LIMIT 1");
    if ($checkCustomer) {
        # code...

        if (mysqli_num_rows($checkCustomer) > 0) {
            # code...
            $_SESSION['invoice_no'] = "INV_" . rand(111111, 999999);
            $_SESSION['customerphone'] = $phone;
            $_SESSION['payment_mode'] = $payment_mode;

            jsonResponse(200, 'success', 'Customer Found');
        } else {
            $_SESSION['customerphone'] = $phone;
            jsonResponse(404, 'warning', 'Customer Not Found');
        }
    } else {

        jsonResponse(500, 'error', 'Something Went Wrong');
    }
}



if (isset($_POST['saveCustomerBtn'])) {
    $name = validate($_POST['name']);
    $phone = validate($_POST['phone']);
    $email = validate($_POST['email']);

    if ($name != '' && $phone != '') {
        $data = [
            'name' => $name,
            'phone' => $phone,
            'email' => $email
        ];
        
        // Assuming you have a function insert that returns true on success and false on failure
        $result = insert('customers', $data);
        
        if ($result) {
            jsonResponse(200, 'success', 'Customer created successfully');
        } else {
            jsonResponse(500, 'error', 'Something went wrong');
        }
    } else {
        jsonResponse(422, 'warning', 'Please fill required fields');
    }
}

if (isset($_POST['saveOrder'])) {

    // $phone = validate($_SESSION['customerphone']);
    // $invoice_no = validate($_SESSION['invoice_no']);
    // $payment_mode = validate($_SESSION['payment_mode']);
    // $order_placed_by_id = $_SESSION['auth_user']['id'];

    // $checkCustomer = mysqli_query($con,"SELECT * FROM customers WHERE phone='$phone' LIMIT 1");
    // if (!$checkCustomer) {
    //     # code...
    //     jsonResponse(500,'error','Something Went Wrong!');
    // }
    // if (mysqli_num_rows($checkCustomer) > 0 ) {
    //     # code...
    //     $customerData = mysqli_fetch_assoc($checkCustomer);

    //     if (!isset($_SESSION['productItem'])) {
    //         # code...
    //         jsonResponse(404,'warning','No Items to Place Order!');
    //     }
    //     $sessionProducts = $_SESSION['productItem'];
    //     $totalAmount = 0;

    //     foreach ($$sessionProducts  as  $amtItem) {
    //         # code...
    //         $totalAmount += $amtItem['price'] * $amtItem['quantity'];
    //     }
    //     $data =[
    //         'customer_id' => $customerData['id'],
    //         'tracking_no' => rand(11111,99999),
    //         'invoice_no' => $invoice_no,
    //         'total_amount' => $totalAmount,
    //         'order_date' => date('Y-m-d'),
    //         'order_status' => 'booked',
    //         'payment_mode' => $payment_mode,
    //         'order_placed_by_id' => $order_placed_by_id,
    //     ];
    //     $result = insert('orders', $data);
    //     $lastOrderId = mysqli_insert_id($con );

    //     foreach ($$sessionProducts  as  $prodItem) {
    //         # code...
    //         $product_id = $prodItem['product_id'];
    //         $price = $prodItem['price'];
    //         $quantity = $prodItem['quantity'];

    //         //Inserting order item

    //         $dataOrderItem =[
    //             'order_id'=>$lastOrderId,
    //             'product_id'=>$product_id,
    //             'price'=>$price,
    //             'quantity'=>$quantity,
    //         ];

    //         $orderInsertQuery = insert('order_items', $dataOrderItem);

    //         //Check for quantity

    //         $checkProductQuantityQuery = mysqli_query($con,"SELECT * FROM products WHERE id='$product_id'");
    //         $checkProductQuantityData = mysqli_fetch_assoc($checkProductQuantityQuery);
    //         $totalProductQuantity = $checkProductQuantityData['quantity'] - $quantity;

    //         $dataUpdate =  [
    //             'quantity'=>$totalProductQuantity
    //         ];

    //         $updateProductQuantity = update('products',$product_id,$dataUpdate);
            
            
    //     }

    //     unset($_SESSION['productItemIds']);
    //     unset($_SESSION['productItem']);
    //     unset($_SESSION['payment_mode']);
    //     unset($_SESSION['invoice_no']);
    //     unset($_SESSION['customerphone']);

    //     jsonResponse(200,'success','OrderPlaced Successfully');
    // }
    // else {
    //     # code...
    //     jsonResponse(404,'warning','No Customer Found');

    // }

    // Check if session variables are set before using them
    $customerphone = isset($_SESSION['customerphone']) ? validate($_SESSION['customerphone']) : null;
    $invoice_no = isset($_SESSION['invoice_no']) ? validate($_SESSION['invoice_no']) : null;
    $payment_mode = isset($_SESSION['payment_mode']) ? validate($_SESSION['payment_mode']) : null;
    $order_placed_by_id = isset($_SESSION['auth_user']['id']) ? $_SESSION['auth_user']['id'] : null;
    
    // Ensure essential session variables are set
    if (!$customerphone || !$invoice_no || !$payment_mode || !$order_placed_by_id) {
        jsonResponse(400, 'error', 'Missing required session variables');
        exit;
    }
    
    // Check if customer exists in the database
    $checkCustomer = mysqli_query($con, "SELECT * FROM customers WHERE phone='$customerphone' LIMIT 1");
    if (!$checkCustomer) {
        jsonResponse(500, 'error', 'Something Went Wrong!');
        exit;
    }
    if (mysqli_num_rows($checkCustomer) > 0) {
        $customerData = mysqli_fetch_assoc($checkCustomer);
    
        // Check if there are products to place an order
        if (!isset($_SESSION['productItem'])) {
            jsonResponse(404, 'warning', 'No Items to Place Order!');
            exit;
        }
        $sessionProducts = $_SESSION['productItem'];
        $totalAmount = 0;
    
        // Calculate total amount
        foreach ($sessionProducts as $amtItem) {
            $totalAmount += $amtItem['price'] * $amtItem['quantity'];
        }
    
        // Prepare order data
        $data = [
            'customer_id' => $customerData['id'],
            'tracking_no' => rand(11111, 99999),
            'invoice_no' => $invoice_no,
            'total_amount' => $totalAmount,
            'order_date' => date('Y-m-d'),
            'order_status' => 'booked',
            'payment_mode' => $payment_mode,
            'order_placed_by_id' => $order_placed_by_id,
        ];
    
        // Insert order data into orders table
        $result = insert('orders', $data);
        if ($result) {
            $lastOrderId = mysqli_insert_id($con);
    
            // Insert order items
            foreach ($sessionProducts as $prodItem) {
                $product_id = $prodItem['product_id'];
                $price = $prodItem['price'];
                $quantity = $prodItem['quantity'];
    
                $dataOrderItem = [
                    'order_id' => $lastOrderId,
                    'product_id' => $product_id,
                    'price' => $price,
                    'quantity' => $quantity,
                ];
    
                $orderInsertQuery = insert('order_items', $dataOrderItem);
    
                // Check and update product quantity
                $checkProductQuantityQuery = mysqli_query($con, "SELECT * FROM products WHERE id='$product_id'");
                if ($checkProductQuantityQuery && mysqli_num_rows($checkProductQuantityQuery) > 0) {
                    $checkProductQuantityData = mysqli_fetch_assoc($checkProductQuantityQuery);
                    $totalProductQuantity = $checkProductQuantityData['quantity'] - $quantity;
    
                    $dataUpdate = [
                        'quantity' => $totalProductQuantity
                    ];
    
                    $updateProductQuantity = update('products', $product_id, $dataUpdate);
                }
            }
    
            // Clear session variables
            unset($_SESSION['productItemIds']);
            unset($_SESSION['productItem']);
            unset($_SESSION['payment_mode']);
            unset($_SESSION['invoice_no']);
            unset($_SESSION['customerphone']);
    
            jsonResponse(200, 'success', 'Order Placed Successfully');
        } else {
            jsonResponse(500, 'error', 'Failed to place order');
        }
    } else {
        jsonResponse(404, 'warning', 'No Customer Found');
    }
}
?>
